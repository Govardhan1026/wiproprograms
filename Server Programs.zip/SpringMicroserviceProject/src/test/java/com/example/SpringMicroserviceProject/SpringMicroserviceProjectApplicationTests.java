package com.example.SpringMicroserviceProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicroserviceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
