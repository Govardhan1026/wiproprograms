package com.springboot.pratice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemosApplicationTests {

	@Test
	void contextLoads() {
	}

}
