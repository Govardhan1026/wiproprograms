package com.example.SpringReactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
