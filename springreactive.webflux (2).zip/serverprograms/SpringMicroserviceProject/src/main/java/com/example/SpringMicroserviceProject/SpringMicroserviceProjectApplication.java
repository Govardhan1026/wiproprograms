package com.example.SpringMicroserviceProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMicroserviceProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMicroserviceProjectApplication.class, args);
	}

}
